package b;

public class HistogramBTest {

}
